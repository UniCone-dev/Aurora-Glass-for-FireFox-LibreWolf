'use strict';

/* =========================================================================
   STORAGE LAYER
   Firefox/LibreWolf WebExtension -> browser.storage.local
   Fallback -> localStorage (so the page also works if opened as a plain file)
   Nothing here ever leaves the device.
   ========================================================================= */
const StorageAPI = {
  async get(key, fallback) {
    try {
      if (typeof browser !== 'undefined' && browser.storage) {
        const res = await browser.storage.local.get(key);
        return (key in res) ? res[key] : fallback;
      }
    } catch (e) {}
    try {
      const raw = localStorage.getItem('ftab:' + key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) { return fallback; }
  },
  async set(key, value) {
    try {
      if (typeof browser !== 'undefined' && browser.storage) {
        await browser.storage.local.set({ [key]: value });
        return;
      }
    } catch (e) {}
    try { localStorage.setItem('ftab:' + key, JSON.stringify(value)); } catch (e) {}
  }
};

/* =========================================================================
   DEFAULT STATE
   ========================================================================= */
function uid() { return Math.random().toString(36).slice(2, 10); }

function defaultState() {
  return {
    accountName: 'User',
    avatar: null,
    panelPos: 'center',
    themeMode: 'auto',
    accent: '#0a63d1',
    accent2: '#22c58b',
    blur: 0,
    panelBlur: 42,
    glassOpacity: 70,
    animations: true,
    trafficLights: true,
    dockMagnify: true,
    squircleIcons: true,
    theme: 'classic',
    shortcutStyle: 'dock',
    searchEngine: 'duckduckgo',
    clockFormat: '24',
    language: 'en',
    customCss: '',
    panel: { width: 760, heightPct: 88, scale: 100, radius: 22 },
    taskbarApps: [],
    googleClientId: '',
    google: null,
    wallpaper: { type: 'gradient', value: 'radial-gradient(circle at 14% 92%, rgba(37,164,255,0.55), transparent 42%), radial-gradient(circle at 88% 8%, rgba(34,197,139,0.5), transparent 46%), linear-gradient(160deg,#eaf6f2 0%,#e3f1fb 55%,#eef7f3 100%)' },
    weather: { lat: null, lon: null, label: '', tz: null },

    aiApps: [
      { id: uid(), name: 'Claude', url: 'https://claude.ai', icon: 'C', color: '#d97757' },
      { id: uid(), name: 'Gemini', url: 'https://gemini.google.com', icon: 'G', color: '#4285f4' },
      { id: uid(), name: 'ChatGPT', url: 'https://chatgpt.com', icon: '⌘', color: '#10a37f' }
    ],

    folders: [
      {
        id: uid(), name: 'Google', color: '#4285f4',
        apps: [
          { id: uid(), name: 'Gmail', url: 'https://mail.google.com', icon: 'M', color: '#ea4335' },
          { id: uid(), name: 'YouTube', url: 'https://youtube.com', icon: '▶', color: '#ff0000' },
          { id: uid(), name: 'Google', url: 'https://google.com', icon: 'G', color: '#4285f4' },
          { id: uid(), name: 'Drive', url: 'https://drive.google.com', icon: 'D', color: '#34a853' }
        ]
      },
      {
        id: uid(), name: 'Customize', color: '#8764b8',
        apps: [
          { id: uid(), name: 'Theme (CSS)', url: '#settings:advanced', icon: '🎨', color: '#8764b8' },
          { id: uid(), name: 'Wallpaper', url: '#settings:appearance', icon: '🖼', color: '#0067c0' },
          { id: uid(), name: 'Layout', url: '#settings:layout', icon: '▦', color: '#107c10' }
        ]
      },
      {
        id: uid(), name: 'Movies & Series', color: '#e50914',
        apps: [
          { id: uid(), name: 'Netflix', url: 'https://netflix.com', icon: 'N', color: '#e50914' },
          { id: uid(), name: 'Prime Video', url: 'https://primevideo.com', icon: 'P', color: '#00a8e1' },
          { id: uid(), name: 'Dailymotion', url: 'https://dailymotion.com', icon: 'D', color: '#0e0e0e' }
        ]
      },
      {
        id: uid(), name: 'Private Chat', color: '#25d366',
        apps: [
          { id: uid(), name: 'WhatsApp', url: 'https://web.whatsapp.com', icon: 'W', color: '#25d366' },
          { id: uid(), name: 'Discord', url: 'https://discord.com/app', icon: 'D', color: '#5865f2' },
          { id: uid(), name: 'Telegram', url: 'https://web.telegram.org', icon: 'T', color: '#229ed9' }
        ]
      },
      {
        id: uid(), name: 'Music', color: '#ff5500',
        apps: [
          { id: uid(), name: 'SoundCloud', url: 'https://soundcloud.com', icon: 'S', color: '#ff5500' },
          { id: uid(), name: 'Spotify', url: 'https://open.spotify.com', icon: '♫', color: '#1db954' }
        ]
      },
      {
        id: uid(), name: 'Other', color: '#605e5c',
        apps: []
      }
    ]
  };
}

/* =========================================================================
   LANGUAGE / i18n
   Formal English (default), Russian, French. Every UI label, hint,
   button and placeholder is covered via data-i18n / data-i18n-ph /
   data-i18n-title attributes in the HTML, swept by applyLanguage().
   App, folder, and link names you type yourself are never translated.
   ========================================================================= */
const LANGS = {
  en: { label: 'English', locale: 'en-US' },
  ru: { label: 'Русский', locale: 'ru-RU' },
  fr: { label: 'Français', locale: 'fr-FR' }
};

const I18N = {
  en: {
    searchPlaceholder: 'Search for apps, settings, links and documents',
    heroGreeting: 'Where to?',
    themeLabel: 'Theme', themeClassic: 'Classic', themeSifiomini: 'Sifiomini',
    shortcutStyleLabel: 'Shortcut style',
    shortcutSquare: 'Square', shortcutIos: 'iOS', shortcutCard: 'Card',
    shortcutCircle: 'Circle', shortcutDock: 'Dock', shortcutMinimal: 'Minimal',
    searchEngineTitle: 'Change search engine',
    sectionAI: 'AI', sectionPinned: 'Pinned', manageBtn: 'Manage',
    settingsTitle: 'Settings', langTitle: 'Language',
    weatherTapTitle: 'Tap to set weather location',
    weatherSetLocation: 'Set your location', weatherTitle: 'Weather',
    taskbarStartTitle: 'Start', taskbarPinTitle: 'Pin an app to the taskbar',
    folderAddApp: '+ Add app',
    weatherSelectTitle: 'Select location',
    weatherCityPlaceholder: 'Enter a city name (any country)',
    weatherSearchBtn: 'Search', weatherUseGeoBtn: '📍 Use my current location',
    tabAppearance: 'Appearance', tabLayout: 'Layout', tabApps: 'Apps & Folders',
    tabAI: 'AI', tabPrivacy: 'Privacy', tabProfile: 'Profile',
    tabAdvanced: 'Advanced CSS', tabAbout: 'About',
    themeModeLabel: 'Theme mode',
    themeAuto: 'Auto (day / night, based on sunrise-sunset)',
    themeLight: 'Light', themeDark: 'Dark',
    accentColorLabel: 'Accent color', accent2ColorLabel: 'Accent gradient (2nd color)',
    wallpaperBlurLabel: 'Wallpaper blur',
    glassOpacityLabel: 'Panel glass opacity', panelBlurLabel: 'Panel blur intensity (vibrancy)',
    wallpaperLabel: 'Wallpaper',
    gradientPresetsBtn: 'Gradient presets', resetBtn: 'Reset',
    animationsLabel: 'Spring animations',
    trafficLightsLabel: 'macOS traffic-light buttons', dockMagnifyLabel: 'Dock hover magnify',
    squircleLabel: 'Squircle app icons (macOS shape)',
    designSectionLabel: 'macOS × Edge style',
    panelPositionLabel: 'Panel position',
    posCenter: 'Center', posTop: 'Top', posBottom: 'Bottom', posLeft: 'Left', posRight: 'Right',
    accountNameLabel: 'Account name', namePlaceholder: 'Your name',
    clockFormatLabel: 'Clock format', clock24: '24-hour', clock12: '12-hour (AM/PM)',
    languageLabel: 'Language',
    panelSizeHint: 'Customize the size of the launcher panel — just like the search bar, fully under your control.',
    panelWidthLabel: 'Panel width', panelHeightLabel: 'Panel max height',
    panelScaleLabel: 'Panel scale', cornerRoundnessLabel: 'Corner roundness',
    foldersHint: 'Add, remove, or rename folders. To add apps inside a folder, open it and use "+ Add app".',
    addFolderBtn: '+ New folder',
    aiHint: 'Cloud AI apps stay pinned. For a local LLM (llama.cpp / Ollama / KoboldAI), enter your own web-UI address — everything runs on your own computer, nothing leaves it.',
    localLlmPresetPlaceholder: 'Choose a local LLM preset…', addBtn: 'Add',
    privacyHint: 'This extension sends no analytics, tracking, or telemetry. All data — folders, apps, theme, wallpaper — stays in this browser\'s local storage only. Only 2 network calls ever happen, and only when you trigger them yourself:',
    privacyItem1: '🔎 Weather lookup (Open-Meteo, no API key, no tracking) — only when you set a location.',
    privacyItem2: '🌐 Opening any link/app you add — only when you click that icon.',
    searchEngineLabel: 'Search engine (privacy-focused)',
    exportBtn: '⬇ Export all settings (JSON)', importBtn: '⬆ Import settings',
    resetAllBtn: '⚠ Reset everything',
    nameLabel: 'Name', profilePhotoLabel: 'Profile photo',
    googleHint: 'Signing in with Google is optional and only works once you enter your own Google OAuth Client ID (free from Google Cloud Console) — for privacy reasons this extension does not use any shared/central login server. Your profile name/photo can also be set manually above without it.',
    googleClientIdLabel: 'Google OAuth Client ID (optional, advanced)',
    googleConnectBtn: '🔗 Connect Google account', googleConnected: 'Connected',
    googleDisconnectBtn: 'Disconnect',
    advancedHint: 'Write your own custom CSS here — it applies instantly across the whole new-tab panel.',
    customCssPlaceholder: '/* write your CSS here */', applyBtn: 'Apply',
    aboutDesc: 'Open-source, privacy-first, Windows-11-style new tab for LibreWolf. No tracking, no analytics, no central server — everything stays local to this browser.',
    creditsDesignLabel: 'Design & project lead', creditsCodingLabel: 'Coding assistance',
    aboutLicense: 'License: MIT. The full source code is just these files — anyone may read, modify, or redistribute it. See the LICENSE file for details.',
    taskbarPickTitle: 'Pin to taskbar', taskbarPickNewBtn: '+ Create a new custom app',
    pinBtn: 'Pin', pinnedBtn: 'Pinned ✓',
    appEditTitleAdd: 'Add app', appEditTitleEdit: 'Edit app',
    appEditNamePlaceholder: 'e.g. YouTube', appEditUrlLabel: 'Link (URL)',
    appEditCustomIconLabel: 'Custom icon image (optional)', clearBtn: 'Clear',
    appEditIconLabel: 'Icon letter / emoji (used if no custom image)',
    appEditIconColorLabel: 'Icon color',
    deleteBtn: 'Delete', saveBtn: 'Save',
    renameBtn: 'Rename', openBtn: 'Open',
    loadingText: 'Loading…', searching: 'Searching…',
    noCityFound: 'No city found. Try another name.',
    networkError: 'Network error — are you offline?',
    gettingLocation: 'Getting your location…',
    locationDenied: 'Location permission was not granted.',
    weatherLoadFailed: 'Could not load weather',
    noAppsYet: 'Add an app to AI or a folder first.',
    confirmDeleteFolder: 'Delete folder',
    confirmReset: 'This will reset all settings, folders, and apps. Continue?',
    invalidFile: 'Invalid file.',
    googleNeedClientId: 'Enter your Google OAuth Client ID first. You can create one for free in Google Cloud Console — see the README for steps.',
    googleNeedExtension: 'Google sign-in only works inside the installed extension (it needs the browser.identity API), not in a plain preview.',
    googleConnectFailed: 'Could not connect to Google. Check your Client ID and authorized redirect URI.',
    promptNewFolder: 'Name for the new folder:', promptRenameFolder: 'New folder name:',
    openLabel: 'Open', searchForLabel: 'Search for'
  },
  ru: {
    searchPlaceholder: 'Поиск приложений, настроек, ссылок и документов',
    heroGreeting: 'Куда пойдём?',
    themeLabel: 'Тема', themeClassic: 'Классическая', themeSifiomini: 'Sifiomini',
    shortcutStyleLabel: 'Стиль ярлыков',
    shortcutSquare: 'Квадрат', shortcutIos: 'iOS', shortcutCard: 'Карточка',
    shortcutCircle: 'Круг', shortcutDock: 'Док', shortcutMinimal: 'Минимальный',
    searchEngineTitle: 'Сменить поисковую систему',
    sectionAI: 'ИИ', sectionPinned: 'Закреплённые', manageBtn: 'Управлять',
    settingsTitle: 'Настройки', langTitle: 'Язык',
    weatherTapTitle: 'Нажмите, чтобы задать местоположение',
    weatherSetLocation: 'Укажите местоположение', weatherTitle: 'Погода',
    taskbarStartTitle: 'Пуск', taskbarPinTitle: 'Закрепить приложение на панели задач',
    folderAddApp: '+ Добавить приложение',
    weatherSelectTitle: 'Выбор местоположения',
    weatherCityPlaceholder: 'Введите название города (любой страны)',
    weatherSearchBtn: 'Найти', weatherUseGeoBtn: '📍 Использовать моё местоположение',
    tabAppearance: 'Внешний вид', tabLayout: 'Макет', tabApps: 'Приложения и папки',
    tabAI: 'ИИ', tabPrivacy: 'Приватность', tabProfile: 'Профиль',
    tabAdvanced: 'Свой CSS', tabAbout: 'О программе',
    themeModeLabel: 'Тема оформления',
    themeAuto: 'Авто (день/ночь по восходу и закату)',
    themeLight: 'Светлая', themeDark: 'Тёмная',
    accentColorLabel: 'Акцентный цвет', accent2ColorLabel: 'Градиент акцента (2-й цвет)',
    wallpaperBlurLabel: 'Размытие обоев',
    glassOpacityLabel: 'Непрозрачность панели', panelBlurLabel: 'Интенсивность размытия панели',
    wallpaperLabel: 'Обои',
    gradientPresetsBtn: 'Готовые градиенты', resetBtn: 'Сбросить',
    animationsLabel: 'Плавные анимации',
    trafficLightsLabel: 'Кнопки в стиле macOS', dockMagnifyLabel: 'Увеличение дока при наведении',
    squircleLabel: 'Иконки-сквиркл (форма macOS)',
    designSectionLabel: 'Стиль macOS × Edge',
    panelPositionLabel: 'Положение панели',
    posCenter: 'По центру', posTop: 'Сверху', posBottom: 'Снизу', posLeft: 'Слева', posRight: 'Справа',
    accountNameLabel: 'Имя пользователя', namePlaceholder: 'Ваше имя',
    clockFormatLabel: 'Формат часов', clock24: '24-часовой', clock12: '12-часовой (AM/PM)',
    languageLabel: 'Язык',
    panelSizeHint: 'Настройте размер панели запуска — так же, как строку поиска, полностью под вашим контролем.',
    panelWidthLabel: 'Ширина панели', panelHeightLabel: 'Макс. высота панели',
    panelScaleLabel: 'Масштаб панели', cornerRoundnessLabel: 'Скругление углов',
    foldersHint: 'Добавляйте, удаляйте или переименовывайте папки. Чтобы добавить приложение внутрь папки, откройте её и нажмите «+ Добавить приложение».',
    addFolderBtn: '+ Новая папка',
    aiHint: 'Облачные ИИ-приложения остаются закреплёнными. Для локальной LLM (llama.cpp / Ollama / KoboldAI) укажите адрес своего веб-интерфейса — всё выполняется на вашем компьютере и никуда не отправляется.',
    localLlmPresetPlaceholder: 'Выберите пресет локальной LLM…', addBtn: 'Добавить',
    privacyHint: 'Это расширение не отправляет аналитику, отслеживание или телеметрию. Все данные — папки, приложения, тема, обои — хранятся только в локальном хранилище этого браузера. Есть только 2 сетевых запроса, и оба — только по вашей инициативе:',
    privacyItem1: '🔎 Запрос погоды (Open-Meteo, без API-ключа, без отслеживания) — только когда вы задаёте местоположение.',
    privacyItem2: '🌐 Открытие добавленной вами ссылки/приложения — только при нажатии на значок.',
    searchEngineLabel: 'Поисковая система (ориентирована на приватность)',
    exportBtn: '⬇ Экспортировать настройки (JSON)', importBtn: '⬆ Импортировать настройки',
    resetAllBtn: '⚠ Сбросить всё',
    nameLabel: 'Имя', profilePhotoLabel: 'Фото профиля',
    googleHint: 'Вход через Google необязателен и работает только после того, как вы укажете свой собственный Google OAuth Client ID (бесплатно в Google Cloud Console) — из соображений приватности расширение не использует общий/центральный сервер входа. Имя и фото профиля можно задать вручную выше и без этого.',
    googleClientIdLabel: 'Google OAuth Client ID (необязательно, для опытных)',
    googleConnectBtn: '🔗 Подключить аккаунт Google', googleConnected: 'Подключено',
    googleDisconnectBtn: 'Отключить',
    advancedHint: 'Напишите здесь свой CSS — он применяется мгновенно ко всей панели новой вкладки.',
    customCssPlaceholder: '/* напишите свой CSS здесь */', applyBtn: 'Применить',
    aboutDesc: 'Открытая, приватная новая вкладка для LibreWolf в стиле Windows 11. Никакого отслеживания, аналитики или центрального сервера — всё остаётся локально в этом браузере.',
    creditsDesignLabel: 'Дизайн и руководство проектом', creditsCodingLabel: 'Помощь в написании кода',
    aboutLicense: 'Лицензия: MIT. Весь исходный код — это только эти файлы, и любой может их читать, изменять и распространять. Подробности — в файле LICENSE.',
    taskbarPickTitle: 'Закрепить на панели задач', taskbarPickNewBtn: '+ Создать новое приложение',
    pinBtn: 'Закрепить', pinnedBtn: 'Закреплено ✓',
    appEditTitleAdd: 'Добавить приложение', appEditTitleEdit: 'Изменить приложение',
    appEditNamePlaceholder: 'например, YouTube', appEditUrlLabel: 'Ссылка (URL)',
    appEditCustomIconLabel: 'Своя иконка (необязательно)', clearBtn: 'Очистить',
    appEditIconLabel: 'Буква/эмодзи для иконки (если нет своей картинки)',
    appEditIconColorLabel: 'Цвет иконки',
    deleteBtn: 'Удалить', saveBtn: 'Сохранить',
    renameBtn: 'Переименовать', openBtn: 'Открыть',
    loadingText: 'Загрузка…', searching: 'Поиск…',
    noCityFound: 'Город не найден. Попробуйте другое название.',
    networkError: 'Ошибка сети — вы не в сети?',
    gettingLocation: 'Определяем ваше местоположение…',
    locationDenied: 'Доступ к местоположению не был предоставлен.',
    weatherLoadFailed: 'Не удалось загрузить погоду',
    noAppsYet: 'Сначала добавьте приложение в ИИ или в папку.',
    confirmDeleteFolder: 'Удалить папку',
    confirmReset: 'Все настройки, папки и приложения будут сброшены. Продолжить?',
    invalidFile: 'Некорректный файл.',
    googleNeedClientId: 'Сначала укажите свой Google OAuth Client ID. Его можно бесплатно создать в Google Cloud Console — см. шаги в README.',
    googleNeedExtension: 'Вход через Google работает только внутри установленного расширения (требуется API browser.identity), а не в обычном предпросмотре.',
    googleConnectFailed: 'Не удалось подключиться к Google. Проверьте Client ID и разрешённый redirect URI.',
    promptNewFolder: 'Название новой папки:', promptRenameFolder: 'Новое название папки:',
    openLabel: 'Открыть', searchForLabel: 'Искать'
  },
  fr: {
    searchPlaceholder: 'Rechercher des applications, paramètres, liens et documents',
    heroGreeting: 'Où aller ?',
    themeLabel: 'Thème', themeClassic: 'Classique', themeSifiomini: 'Sifiomini',
    shortcutStyleLabel: 'Style des raccourcis',
    shortcutSquare: 'Carré', shortcutIos: 'iOS', shortcutCard: 'Carte',
    shortcutCircle: 'Cercle', shortcutDock: 'Dock', shortcutMinimal: 'Minimal',
    searchEngineTitle: 'Changer de moteur de recherche',
    sectionAI: 'IA', sectionPinned: 'Épinglés', manageBtn: 'Gérer',
    settingsTitle: 'Paramètres', langTitle: 'Langue',
    weatherTapTitle: 'Appuyez pour définir la localisation météo',
    weatherSetLocation: 'Définissez votre localisation', weatherTitle: 'Météo',
    taskbarStartTitle: 'Démarrer', taskbarPinTitle: 'Épingler une application à la barre des tâches',
    folderAddApp: '+ Ajouter une application',
    weatherSelectTitle: 'Sélectionner la localisation',
    weatherCityPlaceholder: 'Entrez un nom de ville (tout pays)',
    weatherSearchBtn: 'Rechercher', weatherUseGeoBtn: '📍 Utiliser ma position actuelle',
    tabAppearance: 'Apparence', tabLayout: 'Disposition', tabApps: 'Applications et dossiers',
    tabAI: 'IA', tabPrivacy: 'Confidentialité', tabProfile: 'Profil',
    tabAdvanced: 'CSS avancé', tabAbout: 'À propos',
    themeModeLabel: 'Mode du thème',
    themeAuto: 'Auto (jour/nuit, selon lever et coucher du soleil)',
    themeLight: 'Clair', themeDark: 'Sombre',
    accentColorLabel: 'Couleur d\'accent', accent2ColorLabel: 'Dégradé d\'accent (2e couleur)',
    wallpaperBlurLabel: 'Flou du fond d\'écran',
    glassOpacityLabel: 'Opacité du panneau', panelBlurLabel: 'Intensité du flou (vibrance)',
    wallpaperLabel: 'Fond d\'écran',
    gradientPresetsBtn: 'Dégradés prédéfinis', resetBtn: 'Réinitialiser',
    animationsLabel: 'Animations ressort',
    trafficLightsLabel: 'Boutons style macOS', dockMagnifyLabel: 'Agrandissement du dock au survol',
    squircleLabel: 'Icônes squircle (forme macOS)',
    designSectionLabel: 'Style macOS × Edge',
    panelPositionLabel: 'Position du panneau',
    posCenter: 'Centre', posTop: 'Haut', posBottom: 'Bas', posLeft: 'Gauche', posRight: 'Droite',
    accountNameLabel: 'Nom du compte', namePlaceholder: 'Votre nom',
    clockFormatLabel: 'Format de l\'horloge', clock24: '24 heures', clock12: '12 heures (AM/PM)',
    languageLabel: 'Langue',
    panelSizeHint: 'Personnalisez la taille du panneau de lancement — tout comme la barre de recherche, entièrement sous votre contrôle.',
    panelWidthLabel: 'Largeur du panneau', panelHeightLabel: 'Hauteur max. du panneau',
    panelScaleLabel: 'Échelle du panneau', cornerRoundnessLabel: 'Arrondi des coins',
    foldersHint: 'Ajoutez, supprimez ou renommez des dossiers. Pour ajouter des applications dans un dossier, ouvrez-le et utilisez « + Ajouter une application ».',
    addFolderBtn: '+ Nouveau dossier',
    aiHint: 'Les applications d\'IA cloud restent épinglées. Pour une LLM locale (llama.cpp / Ollama / KoboldAI), indiquez l\'adresse de votre interface web — tout s\'exécute sur votre propre ordinateur, rien n\'en sort.',
    localLlmPresetPlaceholder: 'Choisir un préréglage de LLM locale…', addBtn: 'Ajouter',
    privacyHint: 'Cette extension n\'envoie aucune analyse, aucun suivi ni télémétrie. Toutes les données — dossiers, applications, thème, fond d\'écran — restent uniquement dans le stockage local de ce navigateur. Seuls 2 appels réseau existent, et uniquement lorsque vous les déclenchez vous-même :',
    privacyItem1: '🔎 Recherche météo (Open-Meteo, sans clé API, sans suivi) — uniquement lorsque vous définissez une localisation.',
    privacyItem2: '🌐 Ouverture d\'un lien/application que vous avez ajouté — uniquement lorsque vous cliquez sur cette icône.',
    searchEngineLabel: 'Moteur de recherche (axé confidentialité)',
    exportBtn: '⬇ Exporter tous les paramètres (JSON)', importBtn: '⬆ Importer des paramètres',
    resetAllBtn: '⚠ Tout réinitialiser',
    nameLabel: 'Nom', profilePhotoLabel: 'Photo de profil',
    googleHint: 'La connexion avec Google est facultative et ne fonctionne qu\'après avoir saisi votre propre identifiant client OAuth Google (gratuit via Google Cloud Console) — pour des raisons de confidentialité, cette extension n\'utilise aucun serveur de connexion partagé/central. Le nom et la photo du profil peuvent aussi être définis manuellement ci-dessus sans cela.',
    googleClientIdLabel: 'Identifiant client OAuth Google (facultatif, avancé)',
    googleConnectBtn: '🔗 Connecter un compte Google', googleConnected: 'Connecté',
    googleDisconnectBtn: 'Déconnecter',
    advancedHint: 'Écrivez ici votre propre CSS — il s\'applique instantanément à tout le panneau du nouvel onglet.',
    customCssPlaceholder: '/* écrivez votre CSS ici */', applyBtn: 'Appliquer',
    aboutDesc: 'Nouvel onglet open-source, axé confidentialité, dans le style Windows 11, pour LibreWolf. Aucun suivi, aucune analyse, aucun serveur central — tout reste local à ce navigateur.',
    creditsDesignLabel: 'Conception et direction du projet', creditsCodingLabel: 'Assistance au développement',
    aboutLicense: 'Licence : MIT. Le code source complet tient dans ces quelques fichiers — chacun peut les lire, les modifier ou les redistribuer. Voir le fichier LICENSE pour les détails.',
    taskbarPickTitle: 'Épingler à la barre des tâches', taskbarPickNewBtn: '+ Créer une nouvelle application personnalisée',
    pinBtn: 'Épingler', pinnedBtn: 'Épinglé ✓',
    appEditTitleAdd: 'Ajouter une application', appEditTitleEdit: 'Modifier l\'application',
    appEditNamePlaceholder: 'p. ex. YouTube', appEditUrlLabel: 'Lien (URL)',
    appEditCustomIconLabel: 'Icône personnalisée (facultatif)', clearBtn: 'Effacer',
    appEditIconLabel: 'Lettre / emoji de l\'icône (utilisé sans image personnalisée)',
    appEditIconColorLabel: 'Couleur de l\'icône',
    deleteBtn: 'Supprimer', saveBtn: 'Enregistrer',
    renameBtn: 'Renommer', openBtn: 'Ouvrir',
    loadingText: 'Chargement…', searching: 'Recherche…',
    noCityFound: 'Aucune ville trouvée. Essayez un autre nom.',
    networkError: 'Erreur réseau — êtes-vous hors ligne ?',
    gettingLocation: 'Récupération de votre position…',
    locationDenied: 'L\'autorisation de localisation n\'a pas été accordée.',
    weatherLoadFailed: 'Impossible de charger la météo',
    noAppsYet: 'Ajoutez d\'abord une application dans IA ou dans un dossier.',
    confirmDeleteFolder: 'Supprimer le dossier',
    confirmReset: 'Tous les paramètres, dossiers et applications seront réinitialisés. Continuer ?',
    invalidFile: 'Fichier invalide.',
    googleNeedClientId: 'Saisissez d\'abord votre identifiant client OAuth Google. Vous pouvez en créer un gratuitement dans Google Cloud Console — voir les étapes dans le README.',
    googleNeedExtension: 'La connexion Google fonctionne uniquement dans l\'extension installée (elle nécessite l\'API browser.identity), pas dans un simple aperçu.',
    googleConnectFailed: 'Impossible de se connecter à Google. Vérifiez votre identifiant client et l\'URI de redirection autorisée.',
    promptNewFolder: 'Nom du nouveau dossier :', promptRenameFolder: 'Nouveau nom du dossier :',
    openLabel: 'Ouvrir', searchForLabel: 'Rechercher'
  }
};

function t(key) {
  const dict = I18N[state.language] || I18N.en;
  return dict[key] || I18N.en[key] || key;
}

let state = null;

async function loadState() {
  const saved = await StorageAPI.get('state', null);
  state = saved ? Object.assign(defaultState(), saved) : defaultState();
}
async function saveState() { await StorageAPI.set('state', state); }

/* =========================================================================
   GRADIENT PRESETS
   ========================================================================= */
const GRADIENTS = [
  'radial-gradient(circle at 14% 92%, rgba(37,164,255,0.55), transparent 42%), radial-gradient(circle at 88% 8%, rgba(34,197,139,0.5), transparent 46%), linear-gradient(160deg,#eaf6f2 0%,#e3f1fb 55%,#eef7f3 100%)',
  'radial-gradient(circle at 20% 20%, #2a8fe0, transparent 55%), radial-gradient(circle at 80% 30%, #17c9b0, transparent 55%), radial-gradient(circle at 55% 85%, #38e07a, transparent 55%), #0b3a5c',
  'linear-gradient(135deg,#1e3c72 0%,#2a5298 35%,#6dd5fa 70%,#a6e6ff 100%)',
  'radial-gradient(circle at 25% 25%, #ff9a56, transparent 55%), radial-gradient(circle at 75% 30%, #ff6bcb, transparent 55%), radial-gradient(circle at 50% 80%, #7c6bff, transparent 55%), #1a1033',
  'linear-gradient(135deg,#0f2027,#203a43,#2c5364)',
  'linear-gradient(135deg,#f7971e,#ffd200)',
  'linear-gradient(135deg,#41295a,#2f0743)',
  'linear-gradient(135deg,#134e5e,#71b280)',
  'linear-gradient(135deg,#0067c0,#7f2fff,#ff2fa1)',
  'linear-gradient(135deg,#1c1c1e,#3a3a3c)'
];

/* =========================================================================
   INIT
   ========================================================================= */
document.addEventListener('DOMContentLoaded', async () => {
  await loadState();
  applyAllVisuals();
  applyLanguage();
  renderAI();
  renderFolders();
  renderBottomBar();
  renderTaskbar();
  renderProfile();
  bindStaticEvents();
  startClock();
  buildGradientPresetUI();
  buildLanguageMenu();
  syncSettingsFormFromState();
  if (state.weather.lat) fetchWeather(state.weather.lat, state.weather.lon, state.weather.label);
});

/* =========================================================================
   VISUAL APPLICATION
   ========================================================================= */
function applyAllVisuals() {
  const root = document.documentElement;
  root.style.setProperty('--accent', state.accent);
  root.style.setProperty('--accent2', state.accent2 || '#22c58b');
  root.style.setProperty('--wallpaper-blur', state.blur + 'px');
  root.style.setProperty('--glass-opacity', (state.glassOpacity / 100).toString());
  root.style.setProperty('--panel-blur', (state.panelBlur != null ? state.panelBlur : 42) + 'px');
  root.style.setProperty('--anim-speed', state.animations ? '1' : '0.001');

  root.classList.toggle('traffic-lights', !!state.trafficLights);
  root.classList.toggle('dock-magnify', !!state.dockMagnify);
  root.classList.toggle('squircle', !!state.squircleIcons);
  root.dataset.theme = state.theme || 'classic';
  root.dataset.shortcut = state.shortcutStyle || 'dock';

  document.body.dataset.panelPos = state.panelPos;

  root.style.setProperty('--panel-width', state.panel.width + 'px');
  root.style.setProperty('--panel-max-height', state.panel.heightPct + 'vh');
  root.style.setProperty('--panel-scale', (state.panel.scale / 100).toString());
  root.style.setProperty('--panel-radius', state.panel.radius + 'px');

  const wp = document.getElementById('wallpaper');
  if (state.wallpaper.type === 'image') {
    wp.style.background = `center/cover no-repeat url("${state.wallpaper.value}")`;
  } else {
    wp.style.background = state.wallpaper.value;
  }

  applyThemeMode();
  applyCustomCss();
}

function applyThemeMode() {
  const mode = state.themeMode;
  let dark;
  if (mode === 'dark') dark = true;
  else if (mode === 'light') dark = false;
  else {
    const h = new Date().getHours();
    dark = (h < 6 || h >= 19); // simple sunrise/sunset heuristic
  }
  document.documentElement.classList.toggle('dark', dark);
}

function applyLanguage() {
  document.documentElement.lang = state.language;

  // Generic sweep: any element tagged with data-i18n / data-i18n-ph /
  // data-i18n-title gets its text, placeholder, or title translated.
  document.querySelectorAll('[data-i18n]').forEach(el => {
    el.textContent = t(el.dataset.i18n);
  });
  document.querySelectorAll('[data-i18n-ph]').forEach(el => {
    el.placeholder = t(el.dataset.i18nPh);
  });
  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    el.title = t(el.dataset.i18nTitle);
  });

  if (!state.weather.lat) document.getElementById('weatherText').textContent = t('weatherSetLocation');

  const taskbarLangEl = document.getElementById('taskbarLang');
  if (taskbarLangEl) taskbarLangEl.textContent = state.language.toUpperCase();
}

function buildLanguageMenu() {
  const box = document.getElementById('langList');
  box.innerHTML = '';
  Object.keys(LANGS).forEach(code => {
    const row = document.createElement('div');
    row.className = 'manage-row';
    row.style.cursor = 'pointer';
    row.innerHTML = `<span>${LANGS[code].label}</span><span>${code === state.language ? '✓' : ''}</span>`;
    row.addEventListener('click', async () => {
      state.language = code;
      await saveState();
      applyLanguage();
      buildLanguageMenu();
      document.getElementById('languageSelect').value = code;
      document.getElementById('langMenu').classList.add('hidden');
      renderClock();
    });
    box.appendChild(row);
  });
}

/* =========================================================================
   TASKBAR (OS-style, fixed at bottom of screen)
   ========================================================================= */
function appIconMarkup(app) {
  if (app.customIcon) return `<img src="${app.customIcon}" alt="" />`;
  return escapeHtml(app.icon || (app.name ? app.name[0] : '?'));
}

function renderTaskbar() {
  const box = document.getElementById('taskbarApps');
  box.innerHTML = '';
  state.taskbarApps.forEach(app => {
    const btn = document.createElement('button');
    btn.className = 'taskbar-app-btn';
    btn.title = app.name;
    btn.innerHTML = `
      <span class="tb-dot" style="background:${app.customIcon ? 'transparent' : (app.color || '#0067c0')}">${appIconMarkup(app)}</span>
      <button class="tb-remove" title="Unpin">✕</button>
    `;
    btn.addEventListener('click', (e) => {
      if (e.target.classList.contains('tb-remove')) return;
      openApp(app.url);
    });
    btn.querySelector('.tb-remove').addEventListener('click', async (e) => {
      e.stopPropagation();
      state.taskbarApps = state.taskbarApps.filter(a => a.id !== app.id);
      await saveState();
      renderTaskbar();
    });
    box.appendChild(btn);
  });
}

function openTaskbarPicker() {
  const box = document.getElementById('taskbarPickList');
  box.innerHTML = '';
  const all = [...state.aiApps.map(a => ({ ...a, group: 'AI' }))];
  state.folders.forEach(f => f.apps.forEach(a => all.push({ ...a, group: f.name })));
  if (!all.length) {
    box.innerHTML = `<div class="hint">${t('noAppsYet')}</div>`;
  }
  all.forEach(app => {
    const pinned = state.taskbarApps.some(a => a.url === app.url);
    const row = document.createElement('div');
    row.className = 'manage-row';
    row.innerHTML = `<span>${escapeHtml(app.name)} <span class="hint">(${escapeHtml(app.group)})</span></span>
      <button data-act="pin">${pinned ? t('pinnedBtn') : t('pinBtn')}</button>`;
    row.querySelector('[data-act="pin"]').addEventListener('click', async () => {
      if (pinned) return;
      state.taskbarApps.push({ id: uid(), name: app.name, url: app.url, icon: app.icon, color: app.color });
      await saveState();
      renderTaskbar();
      openTaskbarPicker();
    });
    box.appendChild(row);
  });
  document.getElementById('taskbarPickOverlay').classList.remove('hidden');
}

/* =========================================================================
   PROFILE + GOOGLE SIGN-IN
   ========================================================================= */
function renderProfile() {
  const nameEls = [document.getElementById('accountName')];
  nameEls.forEach(el => { if (el) el.textContent = state.accountName || 'User'; });

  const avatarHtml = state.avatar ? `<img src="${state.avatar}" alt="" />` : (state.accountName || 'U')[0].toUpperCase();
  document.getElementById('accountAvatar').innerHTML = avatarHtml;
  const previewEl = document.getElementById('profileAvatarPreview');
  if (previewEl) previewEl.innerHTML = avatarHtml;

  const nameInput = document.getElementById('profileNameInput');
  if (nameInput) nameInput.value = state.accountName || '';

  const connected = !!state.google;
  const cDiv = document.getElementById('googleConnected');
  const dDiv = document.getElementById('googleDisconnected');
  if (cDiv && dDiv) {
    cDiv.classList.toggle('hidden', !connected);
    dDiv.classList.toggle('hidden', connected);
    if (connected) {
      document.getElementById('googleAccountLabel').textContent = `${state.google.name || ''} (${state.google.email || ''})`;
    }
  }
  const clientInput = document.getElementById('googleClientIdInput');
  if (clientInput) clientInput.value = state.googleClientId || '';
}

async function connectGoogle() {
  const clientId = document.getElementById('googleClientIdInput').value.trim();
  if (!clientId) {
    alert(t('googleNeedClientId'));
    return;
  }
  if (typeof browser === 'undefined' || !browser.identity) {
    alert(t('googleNeedExtension'));
    return;
  }
  state.googleClientId = clientId;
  await saveState();
  try {
    const redirectUri = browser.identity.getRedirectURL();
    const authUrl = 'https://accounts.google.com/o/oauth2/v2/auth'
      + `?client_id=${encodeURIComponent(clientId)}`
      + `&response_type=token`
      + `&redirect_uri=${encodeURIComponent(redirectUri)}`
      + `&scope=${encodeURIComponent('openid email profile')}`;
    const resultUrl = await browser.identity.launchWebAuthFlow({ url: authUrl, interactive: true });
    const hash = new URL(resultUrl).hash.replace(/^#/, '');
    const params = new URLSearchParams(hash);
    const accessToken = params.get('access_token');
    if (!accessToken) throw new Error('no token');
    const res = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
      headers: { Authorization: `Bearer ${accessToken}` }
    });
    const info = await res.json();
    state.google = { name: info.name, email: info.email, picture: info.picture };
    if (info.name) state.accountName = info.name;
    if (info.picture) state.avatar = info.picture;
    await saveState();
    renderProfile();
    renderBottomBar();
  } catch (e) {
    alert(t('googleConnectFailed'));
  }
}

async function disconnectGoogle() {
  state.google = null;
  await saveState();
  renderProfile();
}

function applyCustomCss() {
  let tag = document.getElementById('userCustomCss');
  if (!tag) {
    tag = document.createElement('style');
    tag.id = 'userCustomCss';
    document.head.appendChild(tag);
  }
  tag.textContent = state.customCss || '';
}

/* =========================================================================
   RENDER: AI ROW
   ========================================================================= */
function renderAI() {
  const row = document.getElementById('aiRow');
  row.innerHTML = '';
  state.aiApps.forEach(app => row.appendChild(makeAppTile(app, () => openApp(app.url))));
  const addTile = makeAddTile(() => openAppEditor({ mode: 'create-ai' }));
  row.appendChild(addTile);
}

/* =========================================================================
   RENDER: FOLDERS
   ========================================================================= */
function renderFolders() {
  const grid = document.getElementById('folderGrid');
  grid.innerHTML = '';
  state.folders.forEach(folder => {
    const tile = document.createElement('div');
    tile.className = 'folder-tile';
    tile.innerHTML = `
      <div class="folder-icon-grid">${folderPreviewSquares(folder)}</div>
      <div class="folder-name">${escapeHtml(folder.name)}</div>
    `;
    tile.addEventListener('click', () => openFolder(folder.id));
    grid.appendChild(tile);
  });
}

function folderPreviewSquares(folder) {
  const colors = folder.apps.slice(0, 4).map(a => a.color || folder.color || '#0067c0');
  while (colors.length < 4) colors.push('rgba(120,120,120,0.25)');
  return colors.map(c => `<span style="background:${c}"></span>`).join('');
}

/* =========================================================================
   TILE FACTORIES
   ========================================================================= */
function makeAppTile(app, onClick) {
  const btn = document.createElement('button');
  btn.className = 'app-tile';
  btn.innerHTML = `
    <div class="app-icon" style="background:${app.customIcon ? 'transparent' : (app.color || '#0067c0')}">${appIconMarkup(app)}</div>
    <div class="app-label">${escapeHtml(app.name)}</div>
  `;
  btn.addEventListener('click', onClick);
  btn.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    openAppEditor({ mode: 'edit', app });
  });
  return btn;
}

function makeAddTile(onClick) {
  const btn = document.createElement('button');
  btn.className = 'app-tile add-tile';
  btn.innerHTML = `<div class="app-icon">+</div><div class="app-label">Add</div>`;
  btn.addEventListener('click', onClick);
  return btn;
}

function openApp(url) {
  if (!url) return;
  if (url.startsWith('#settings:')) {
    const tab = url.split(':')[1];
    openSettings(tab);
    return;
  }
  window.location.href = url;
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, s => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[s]));
}

/* =========================================================================
   FOLDER OVERLAY
   ========================================================================= */
let activeFolderId = null;

function openFolder(id) {
  activeFolderId = id;
  const folder = state.folders.find(f => f.id === id);
  if (!folder) return;
  document.getElementById('folderOverlayTitle').textContent = folder.name;
  const grid = document.getElementById('folderOverlayGrid');
  grid.innerHTML = '';
  folder.apps.forEach(app => grid.appendChild(makeAppTile(app, () => openApp(app.url))));
  document.getElementById('folderOverlay').classList.remove('hidden');
}

function closeFolder() {
  document.getElementById('folderOverlay').classList.add('hidden');
  activeFolderId = null;
}

/* =========================================================================
   APP EDITOR (create / edit / delete pinned app or folder app)
   ========================================================================= */
let editorCtx = null;

function openAppEditor(ctx) {
  editorCtx = ctx;
  const isEdit = ctx.mode === 'edit';
  document.getElementById('appEditTitle').textContent = isEdit ? t('appEditTitleEdit') : t('appEditTitleAdd');
  document.getElementById('appEditName').value = isEdit ? ctx.app.name : '';
  document.getElementById('appEditUrl').value = isEdit ? ctx.app.url : '';
  document.getElementById('appEditIcon').value = isEdit ? (ctx.app.icon || '') : '';
  document.getElementById('appEditColor').value = isEdit ? (ctx.app.color || '#0067c0') : '#0067c0';
  document.getElementById('appEditDeleteBtn').classList.toggle('hidden', !isEdit);

  editorCtx.pendingCustomIcon = undefined;
  editorCtx.clearCustomIcon = false;
  const preview = document.getElementById('appEditIconPreview');
  const clearBtn = document.getElementById('appEditIconClearBtn');
  const existingIcon = isEdit ? ctx.app.customIcon : null;
  if (existingIcon) {
    preview.src = existingIcon;
    preview.classList.remove('hidden');
    clearBtn.classList.remove('hidden');
  } else {
    preview.src = '';
    preview.classList.add('hidden');
    clearBtn.classList.add('hidden');
  }
  document.getElementById('appEditIconUpload').value = '';

  document.getElementById('appEditOverlay').classList.remove('hidden');
}
function closeAppEditor() {
  document.getElementById('appEditOverlay').classList.add('hidden');
  editorCtx = null;
}

async function saveAppEditor() {
  const name = document.getElementById('appEditName').value.trim() || 'App';
  let url = document.getElementById('appEditUrl').value.trim();
  if (url && !url.startsWith('#') && !/^https?:\/\//i.test(url)) url = 'https://' + url;
  const icon = document.getElementById('appEditIcon').value.trim() || name[0].toUpperCase();
  const color = document.getElementById('appEditColor').value;

  if (!editorCtx) return;

  let customIcon;
  if (editorCtx.pendingCustomIcon) customIcon = editorCtx.pendingCustomIcon;
  else if (editorCtx.mode === 'edit' && !editorCtx.clearCustomIcon) customIcon = editorCtx.app.customIcon;

  if (editorCtx.mode === 'create-ai') {
    state.aiApps.push({ id: uid(), name, url, icon, color, customIcon });
  } else if (editorCtx.mode === 'create-folder-app') {
    const folder = state.folders.find(f => f.id === editorCtx.folderId);
    if (folder) folder.apps.push({ id: uid(), name, url, icon, color, customIcon });
  } else if (editorCtx.mode === 'create-taskbar') {
    state.taskbarApps.push({ id: uid(), name, url, icon, color, customIcon });
  } else if (editorCtx.mode === 'edit') {
    editorCtx.app.name = name;
    editorCtx.app.url = url;
    editorCtx.app.icon = icon;
    editorCtx.app.color = color;
    if (customIcon) editorCtx.app.customIcon = customIcon;
    else delete editorCtx.app.customIcon;
  }

  await saveState();
  renderAI();
  renderFolders();
  renderTaskbar();
  if (activeFolderId) openFolder(activeFolderId);
  refreshManageLists();
  closeAppEditor();
}

async function deleteCurrentApp() {
  if (!editorCtx || editorCtx.mode !== 'edit') return;
  const target = editorCtx.app;
  const aiIdx = state.aiApps.findIndex(a => a.id === target.id);
  if (aiIdx >= 0) state.aiApps.splice(aiIdx, 1);
  state.folders.forEach(f => {
    const idx = f.apps.findIndex(a => a.id === target.id);
    if (idx >= 0) f.apps.splice(idx, 1);
  });
  state.taskbarApps = state.taskbarApps.filter(a => a.id !== target.id);
  await saveState();
  renderAI();
  renderFolders();
  if (activeFolderId) openFolder(activeFolderId);
  refreshManageLists();
  closeAppEditor();
}

/* =========================================================================
   SEARCH
   ========================================================================= */
const SEARCH_ENGINES = {
  duckduckgo: { label: 'DuckDuckGo', url: 'https://duckduckgo.com/?q=' },
  startpage: { label: 'Startpage', url: 'https://www.startpage.com/sp/search?query=' },
  brave: { label: 'Brave', url: 'https://search.brave.com/search?q=' },
  google: { label: 'Google', url: 'https://www.google.com/search?q=' },
  bing: { label: 'Bing', url: 'https://www.bing.com/search?q=' }
};

function looksLikeUrl(text) {
  const t = text.trim();
  if (/^https?:\/\//i.test(t)) return true;
  if (/^[\w-]+(\.[\w-]+)+([/?#].*)?$/i.test(t) && !t.includes(' ')) return true;
  return false;
}

function runSearch(query) {
  const q = query.trim();
  if (!q) return;
  if (looksLikeUrl(q)) {
    const url = /^https?:\/\//i.test(q) ? q : 'https://' + q;
    window.location.href = url;
    return;
  }
  const eng = SEARCH_ENGINES[state.searchEngine] || SEARCH_ENGINES.duckduckgo;
  window.location.href = eng.url + encodeURIComponent(q);
}

function updateSearchSuggestions(query) {
  const box = document.getElementById('searchSuggestions');
  box.innerHTML = '';
  const q = query.trim();
  if (!q) return;

  // Matching pinned apps / folder apps
  const all = [...state.aiApps.map(a => ({ ...a, group: 'AI' }))];
  state.folders.forEach(f => f.apps.forEach(a => all.push({ ...a, group: f.name })));
  const matches = all.filter(a => a.name.toLowerCase().includes(q.toLowerCase())).slice(0, 5);

  matches.forEach(m => {
    const row = document.createElement('div');
    row.className = 'suggestion-row';
    row.innerHTML = `<span>${escapeHtml(m.name)}</span><span class="s-badge">${escapeHtml(m.group)}</span>`;
    row.addEventListener('click', () => openApp(m.url));
    box.appendChild(row);
  });

  const goRow = document.createElement('div');
  goRow.className = 'suggestion-row';
  const willUrl = looksLikeUrl(q);
  goRow.innerHTML = willUrl
    ? `<span>${t('openLabel')} "${escapeHtml(q)}"</span><span class="s-badge">Link</span>`
    : `<span>${t('searchForLabel')} "${escapeHtml(q)}"</span><span class="s-badge">${SEARCH_ENGINES[state.searchEngine].label}</span>`;
  goRow.addEventListener('click', () => runSearch(q));
  box.appendChild(goRow);
}

/* =========================================================================
   WEATHER  (Open-Meteo — free, keyless, no tracking; only called on demand)
   ========================================================================= */
const WEATHER_ICON_MAP = {
  0: '☀️', 1: '🌤', 2: '⛅', 3: '☁️',
  45: '🌫', 48: '🌫',
  51: '🌦', 53: '🌦', 55: '🌦',
  61: '🌧', 63: '🌧', 65: '🌧',
  71: '🌨', 73: '🌨', 75: '🌨',
  80: '🌦', 81: '🌧', 82: '⛈',
  95: '⛈', 96: '⛈', 99: '⛈'
};

async function searchCity(name) {
  const box = document.getElementById('weatherResults');
  box.innerHTML = `<div class="hint">${t('searching')}</div>`;
  try {
    const res = await fetch(`https://geocoding-api.open-meteo.com/v1/search?count=8&name=${encodeURIComponent(name)}`);
    const data = await res.json();
    box.innerHTML = '';
    if (!data.results || !data.results.length) {
      box.innerHTML = `<div class="hint">${t('noCityFound')}</div>`;
      return;
    }
    data.results.forEach(r => {
      const row = document.createElement('div');
      row.className = 'weather-result-row';
      const label = [r.name, r.admin1, r.country].filter(Boolean).join(', ');
      row.textContent = label;
      row.addEventListener('click', async () => {
        state.weather = { lat: r.latitude, lon: r.longitude, label, tz: r.timezone || null };
        await saveState();
        document.getElementById('weatherOverlay').classList.add('hidden');
        fetchWeather(r.latitude, r.longitude, label);
      });
      box.appendChild(row);
    });
  } catch (e) {
    box.innerHTML = `<div class="hint">${t('networkError')}</div>`;
  }
}

function useGeolocation() {
  if (!navigator.geolocation) return;
  const box = document.getElementById('weatherResults');
  box.innerHTML = `<div class="hint">${t('gettingLocation')}</div>`;
  navigator.geolocation.getCurrentPosition(async (pos) => {
    const { latitude, longitude } = pos.coords;
    state.weather = { lat: latitude, lon: longitude, label: 'Current location', tz: null };
    await saveState();
    document.getElementById('weatherOverlay').classList.add('hidden');
    fetchWeather(latitude, longitude, 'Current location');
  }, () => {
    box.innerHTML = `<div class="hint">${t('locationDenied')}</div>`;
  });
}

async function fetchWeather(lat, lon, label) {
  const iconEl = document.getElementById('weatherIcon');
  const textEl = document.getElementById('weatherText');
  const tbWeatherEl = document.getElementById('taskbarWeather');
  textEl.textContent = t('loadingText');
  try {
    const res = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&timezone=auto`);
    const data = await res.json();
    const cw = data.current_weather;
    if (!cw) throw new Error('no data');
    const icon = WEATHER_ICON_MAP[cw.weathercode] || '⛅';
    const temp = Math.round(cw.temperature);
    iconEl.textContent = icon;
    textEl.textContent = `${temp}°C · ${label || ''}`.trim();
    if (tbWeatherEl) tbWeatherEl.textContent = `${icon} ${temp}°`;
    if (data.timezone) {
      state.weather.tz = data.timezone;
      await saveState();
      startClock(); // restart clock with new timezone
    }
  } catch (e) {
    textEl.textContent = t('weatherLoadFailed');
  }
}

/* =========================================================================
   CLOCK
   ========================================================================= */
let clockTimer = null;
function startClock() {
  if (clockTimer) clearInterval(clockTimer);
  renderClock();
  clockTimer = setInterval(renderClock, 1000 * 15);
}
function renderClock() {
  const now = new Date();
  const tz = state.weather.tz || undefined;
  const locale = (LANGS[state.language] && LANGS[state.language].locale) || 'en-US';
  try {
    const timeFmt = new Intl.DateTimeFormat(locale, {
      hour: '2-digit', minute: '2-digit',
      hour12: state.clockFormat === '12',
      timeZone: tz
    });
    const dateFmt = new Intl.DateTimeFormat(locale, {
      weekday: 'short', day: 'numeric', month: 'short',
      timeZone: tz
    });
    const timeStr = timeFmt.format(now);
    document.getElementById('clockTime').textContent = timeStr;
    document.getElementById('clockDate').textContent = dateFmt.format(now);
    const tbClock = document.getElementById('taskbarClock');
    if (tbClock) tbClock.textContent = timeStr;
  } catch (e) {
    document.getElementById('clockTime').textContent = now.toLocaleTimeString();
  }
}

/* =========================================================================
   BOTTOM BAR
   ========================================================================= */
function renderBottomBar() {
  renderProfile();
  document.getElementById('weatherText').textContent = state.weather.lat ? t('loadingText') : t('weatherSetLocation');
}

/* =========================================================================
   SETTINGS PANEL
   ========================================================================= */
function openSettings(tab) {
  document.getElementById('settingsOverlay').classList.remove('hidden');
  if (tab) switchSettingsTab(tab);
  refreshManageLists();
}
function closeSettings() {
  document.getElementById('settingsOverlay').classList.add('hidden');
}
function switchSettingsTab(tab) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.toggle('active', p.dataset.panel === tab));
}

function syncSettingsFormFromState() {
  document.getElementById('themeModeSelect').value = state.themeMode;
  document.getElementById('accentColorInput').value = state.accent;
  document.getElementById('accent2ColorInput').value = state.accent2 || '#22c58b';
  document.getElementById('blurRange').value = state.blur;
  document.getElementById('glassRange').value = state.glassOpacity;
  document.getElementById('panelBlurRange').value = state.panelBlur != null ? state.panelBlur : 42;
  document.getElementById('animToggle').checked = state.animations;
  document.getElementById('trafficToggle').checked = state.trafficLights;
  document.getElementById('dockMagnifyToggle').checked = state.dockMagnify;
  document.getElementById('squircleToggle').checked = state.squircleIcons;
  document.querySelectorAll('.theme-swatch').forEach(b => b.classList.toggle('active', b.dataset.theme === (state.theme || 'classic')));
  document.querySelectorAll('.shortcut-swatch').forEach(b => b.classList.toggle('active', b.dataset.shortcut === (state.shortcutStyle || 'dock')));
  document.getElementById('panelPosSelect').value = state.panelPos;
  document.getElementById('accountNameInput').value = state.accountName;
  document.getElementById('clockFormatSelect').value = state.clockFormat;
  document.getElementById('searchEngineSelect').value = state.searchEngine;
  document.getElementById('searchEngineBtn').textContent = SEARCH_ENGINES[state.searchEngine].label;
  document.getElementById('customCssInput').value = state.customCss;
  document.getElementById('languageSelect').value = state.language;
  document.getElementById('panelWidthRange').value = state.panel.width;
  document.getElementById('panelHeightRange').value = state.panel.heightPct;
  document.getElementById('panelScaleRange').value = state.panel.scale;
  document.getElementById('panelRadiusRange').value = state.panel.radius;
}

function buildGradientPresetUI() {
  const box = document.getElementById('gradientPresets');
  box.innerHTML = '';
  GRADIENTS.forEach(g => {
    const sw = document.createElement('div');
    sw.className = 'gradient-swatch';
    sw.style.background = g;
    sw.addEventListener('click', async () => {
      state.wallpaper = { type: 'gradient', value: g };
      await saveState();
      applyAllVisuals();
    });
    box.appendChild(sw);
  });
}

function refreshManageLists() {
  // Folders manage list
  const fBox = document.getElementById('folderManageList');
  fBox.innerHTML = '';
  state.folders.forEach(f => {
    const row = document.createElement('div');
    row.className = 'manage-row';
    row.innerHTML = `<span>${escapeHtml(f.name)} <span class="hint">(${f.apps.length} apps)</span></span>
      <span class="manage-actions">
        <button data-act="rename">${t('renameBtn')}</button>
        <button data-act="open">${t('openBtn')}</button>
        <button data-act="delete">${t('deleteBtn')}</button>
      </span>`;
    row.querySelector('[data-act="rename"]').addEventListener('click', async () => {
      const name = prompt(t('promptRenameFolder'), f.name);
      if (name && name.trim()) { f.name = name.trim(); await saveState(); renderFolders(); refreshManageLists(); }
    });
    row.querySelector('[data-act="open"]').addEventListener('click', () => { closeSettings(); openFolder(f.id); });
    row.querySelector('[data-act="delete"]').addEventListener('click', async () => {
      if (!confirm(`${t('confirmDeleteFolder')}: "${f.name}"?`)) return;
      state.folders = state.folders.filter(x => x.id !== f.id);
      await saveState(); renderFolders(); refreshManageLists();
    });
    fBox.appendChild(row);
  });

  // AI manage list
  const aBox = document.getElementById('aiManageList');
  aBox.innerHTML = '';
  state.aiApps.forEach(a => {
    const row = document.createElement('div');
    row.className = 'manage-row';
    row.innerHTML = `<span>${escapeHtml(a.name)}</span>
      <span class="manage-actions">
        <button data-act="edit">${t('appEditTitleEdit')}</button>
        <button data-act="delete">${t('deleteBtn')}</button>
      </span>`;
    row.querySelector('[data-act="edit"]').addEventListener('click', () => openAppEditor({ mode: 'edit', app: a }));
    row.querySelector('[data-act="delete"]').addEventListener('click', async () => {
      state.aiApps = state.aiApps.filter(x => x.id !== a.id);
      await saveState(); renderAI(); refreshManageLists();
    });
    aBox.appendChild(row);
  });
}

/* =========================================================================
   EXPORT / IMPORT / RESET
   ========================================================================= */
function exportData() {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'fluent-tab-settings.json';
  a.click();
  URL.revokeObjectURL(url);
}

function importData(file) {
  const reader = new FileReader();
  reader.onload = async () => {
    try {
      const parsed = JSON.parse(reader.result);
      state = Object.assign(defaultState(), parsed);
      await saveState();
      applyAllVisuals(); applyLanguage(); renderAI(); renderFolders(); renderBottomBar(); renderTaskbar(); renderProfile();
      syncSettingsFormFromState(); refreshManageLists(); buildLanguageMenu();
      if (state.weather.lat) fetchWeather(state.weather.lat, state.weather.lon, state.weather.label);
    } catch (e) { alert(t('invalidFile')); }
  };
  reader.readAsText(file);
}

async function resetAll() {
  if (!confirm(t('confirmReset'))) return;
  state = defaultState();
  await saveState();
  applyAllVisuals(); applyLanguage(); renderAI(); renderFolders(); renderBottomBar(); renderTaskbar(); renderProfile();
  syncSettingsFormFromState(); refreshManageLists(); buildLanguageMenu();
}

/* =========================================================================
   EVENT BINDING
   ========================================================================= */
function bindStaticEvents() {
  // Search
  const input = document.getElementById('searchInput');
  input.addEventListener('input', () => updateSearchSuggestions(input.value));
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') runSearch(input.value); });
  input.focus();

  document.getElementById('searchEngineBtn').addEventListener('click', () => openSettings('privacy'));

  // Settings open/close
  document.getElementById('settingsBtn').addEventListener('click', () => openSettings());
  document.getElementById('settingsClose').addEventListener('click', closeSettings);
  document.getElementById('settingsOverlay').addEventListener('click', (e) => { if (e.target.id === 'settingsOverlay') closeSettings(); });

  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => switchSettingsTab(btn.dataset.tab));
  });

  document.querySelectorAll('[data-manage]').forEach(btn => {
    btn.addEventListener('click', () => openSettings(btn.dataset.manage === 'ai' ? 'ai' : 'apps'));
  });

  // Folder overlay
  document.getElementById('folderOverlayClose').addEventListener('click', closeFolder);
  document.getElementById('folderOverlay').addEventListener('click', (e) => { if (e.target.id === 'folderOverlay') closeFolder(); });
  document.getElementById('folderAddAppBtn').addEventListener('click', () => {
    if (!activeFolderId) return;
    openAppEditor({ mode: 'create-folder-app', folderId: activeFolderId });
  });

  // App editor
  document.getElementById('appEditClose').addEventListener('click', closeAppEditor);
  document.getElementById('appEditOverlay').addEventListener('click', (e) => { if (e.target.id === 'appEditOverlay') closeAppEditor(); });
  document.getElementById('appEditSaveBtn').addEventListener('click', saveAppEditor);
  document.getElementById('appEditDeleteBtn').addEventListener('click', deleteCurrentApp);
  document.getElementById('appEditIconUpload').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file || !editorCtx) return;
    const reader = new FileReader();
    reader.onload = () => {
      editorCtx.pendingCustomIcon = reader.result;
      editorCtx.clearCustomIcon = false;
      const preview = document.getElementById('appEditIconPreview');
      preview.src = reader.result;
      preview.classList.remove('hidden');
      document.getElementById('appEditIconClearBtn').classList.remove('hidden');
    };
    reader.readAsDataURL(file);
  });
  document.getElementById('appEditIconClearBtn').addEventListener('click', () => {
    if (!editorCtx) return;
    editorCtx.pendingCustomIcon = undefined;
    editorCtx.clearCustomIcon = true;
    document.getElementById('appEditIconPreview').classList.add('hidden');
    document.getElementById('appEditIconClearBtn').classList.add('hidden');
    document.getElementById('appEditIconUpload').value = '';
  });

  // Weather overlay
  document.getElementById('weatherChip').addEventListener('click', () => document.getElementById('weatherOverlay').classList.remove('hidden'));
  document.getElementById('taskbarWeather').addEventListener('click', () => document.getElementById('weatherOverlay').classList.remove('hidden'));
  document.getElementById('weatherOverlayClose').addEventListener('click', () => document.getElementById('weatherOverlay').classList.add('hidden'));
  document.getElementById('weatherOverlay').addEventListener('click', (e) => { if (e.target.id === 'weatherOverlay') e.currentTarget.classList.add('hidden'); });
  document.getElementById('weatherCitySearchBtn').addEventListener('click', () => searchCity(document.getElementById('weatherCityInput').value));
  document.getElementById('weatherCityInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') searchCity(e.target.value); });
  document.getElementById('weatherUseGeoBtn').addEventListener('click', useGeolocation);

  // Appearance controls
  document.getElementById('themeModeSelect').addEventListener('change', async (e) => { state.themeMode = e.target.value; await saveState(); applyThemeMode(); });
  document.getElementById('accentColorInput').addEventListener('input', async (e) => { state.accent = e.target.value; await saveState(); applyAllVisuals(); });
  document.getElementById('accent2ColorInput').addEventListener('input', async (e) => { state.accent2 = e.target.value; await saveState(); applyAllVisuals(); });
  document.getElementById('blurRange').addEventListener('input', async (e) => { state.blur = Number(e.target.value); await saveState(); applyAllVisuals(); });
  document.getElementById('glassRange').addEventListener('input', async (e) => { state.glassOpacity = Number(e.target.value); await saveState(); applyAllVisuals(); });
  document.getElementById('panelBlurRange').addEventListener('input', async (e) => { state.panelBlur = Number(e.target.value); await saveState(); applyAllVisuals(); });
  document.getElementById('animToggle').addEventListener('change', async (e) => { state.animations = e.target.checked; await saveState(); applyAllVisuals(); });
  document.getElementById('trafficToggle').addEventListener('change', async (e) => { state.trafficLights = e.target.checked; await saveState(); applyAllVisuals(); });
  document.getElementById('dockMagnifyToggle').addEventListener('change', async (e) => { state.dockMagnify = e.target.checked; await saveState(); applyAllVisuals(); });
  document.getElementById('squircleToggle').addEventListener('change', async (e) => { state.squircleIcons = e.target.checked; await saveState(); applyAllVisuals(); });
  document.querySelectorAll('.theme-swatch').forEach(btn => {
    btn.addEventListener('click', async () => {
      state.theme = btn.dataset.theme;
      await saveState(); applyAllVisuals(); syncSettingsFormFromState();
    });
  });
  document.querySelectorAll('.shortcut-swatch').forEach(btn => {
    btn.addEventListener('click', async () => {
      state.shortcutStyle = btn.dataset.shortcut;
      await saveState(); applyAllVisuals(); syncSettingsFormFromState();
    });
  });

  document.getElementById('wallpaperUpload').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      state.wallpaper = { type: 'image', value: reader.result };
      await saveState(); applyAllVisuals();
    };
    reader.readAsDataURL(file);
  });
  document.getElementById('wallpaperGradientBtn').addEventListener('click', () => {
    document.getElementById('gradientPresets').classList.toggle('hidden');
  });
  document.getElementById('wallpaperResetBtn').addEventListener('click', async () => {
    state.wallpaper = defaultState().wallpaper;
    await saveState(); applyAllVisuals();
  });

  // Layout controls
  document.getElementById('panelPosSelect').addEventListener('change', async (e) => { state.panelPos = e.target.value; await saveState(); applyAllVisuals(); });
  document.getElementById('accountNameInput').addEventListener('input', async (e) => { state.accountName = e.target.value || 'User'; await saveState(); renderBottomBar(); });
  document.getElementById('clockFormatSelect').addEventListener('change', async (e) => { state.clockFormat = e.target.value; await saveState(); renderClock(); });

  // Apps & folders
  document.getElementById('addFolderBtn').addEventListener('click', async () => {
    const name = prompt(t('promptNewFolder'));
    if (!name || !name.trim()) return;
    state.folders.push({ id: uid(), name: name.trim(), color: '#0067c0', apps: [] });
    await saveState(); renderFolders(); refreshManageLists();
  });

  // AI local LLM presets
  document.getElementById('addLocalLlmBtn').addEventListener('click', async () => {
    const sel = document.getElementById('localLlmPreset');
    if (!sel.value) return;
    const nameMap = {
      'http://127.0.0.1:8080': 'llama.cpp',
      'http://127.0.0.1:11434': 'Ollama',
      'http://127.0.0.1:5001': 'KoboldAI',
      'http://127.0.0.1:7860': 'Text-gen-webui'
    };
    state.aiApps.push({ id: uid(), name: nameMap[sel.value] || 'Local LLM', url: sel.value, icon: '🖥', color: '#107c10' });
    await saveState(); renderAI(); refreshManageLists();
    sel.value = '';
  });

  // Privacy tab
  document.getElementById('searchEngineSelect').addEventListener('change', async (e) => {
    state.searchEngine = e.target.value; await saveState();
    document.getElementById('searchEngineBtn').textContent = SEARCH_ENGINES[state.searchEngine].label;
  });
  document.getElementById('exportDataBtn').addEventListener('click', exportData);
  document.getElementById('importDataBtn').addEventListener('click', () => document.getElementById('importFileInput').click());
  document.getElementById('importFileInput').addEventListener('change', (e) => { if (e.target.files[0]) importData(e.target.files[0]); });
  document.getElementById('resetAllBtn').addEventListener('click', resetAll);

  // Advanced CSS
  document.getElementById('applyCustomCssBtn').addEventListener('click', async () => {
    state.customCss = document.getElementById('customCssInput').value;
    await saveState(); applyCustomCss();
  });

  // Language
  document.getElementById('languageSelect').addEventListener('change', async (e) => {
    state.language = e.target.value; await saveState();
    applyLanguage(); buildLanguageMenu(); renderClock();
  });
  document.getElementById('langBtn').addEventListener('click', () => document.getElementById('langMenu').classList.remove('hidden'));
  document.getElementById('langMenuClose').addEventListener('click', () => document.getElementById('langMenu').classList.add('hidden'));
  document.getElementById('langMenu').addEventListener('click', (e) => { if (e.target.id === 'langMenu') e.currentTarget.classList.add('hidden'); });
  document.getElementById('taskbarLang').addEventListener('click', () => document.getElementById('langMenu').classList.remove('hidden'));

  // Panel size
  document.getElementById('panelWidthRange').addEventListener('input', async (e) => { state.panel.width = Number(e.target.value); await saveState(); applyAllVisuals(); });
  document.getElementById('panelHeightRange').addEventListener('input', async (e) => { state.panel.heightPct = Number(e.target.value); await saveState(); applyAllVisuals(); });
  document.getElementById('panelScaleRange').addEventListener('input', async (e) => { state.panel.scale = Number(e.target.value); await saveState(); applyAllVisuals(); });
  document.getElementById('panelRadiusRange').addEventListener('input', async (e) => { state.panel.radius = Number(e.target.value); await saveState(); applyAllVisuals(); });

  // Taskbar
  document.getElementById('taskbarStartBtn').addEventListener('click', () => document.getElementById('searchInput').focus());
  document.getElementById('taskbarAddBtn').addEventListener('click', openTaskbarPicker);
  document.getElementById('taskbarPickClose').addEventListener('click', () => document.getElementById('taskbarPickOverlay').classList.add('hidden'));
  document.getElementById('taskbarPickOverlay').addEventListener('click', (e) => { if (e.target.id === 'taskbarPickOverlay') e.currentTarget.classList.add('hidden'); });
  document.getElementById('taskbarPickNewBtn').addEventListener('click', () => {
    document.getElementById('taskbarPickOverlay').classList.add('hidden');
    openAppEditor({ mode: 'create-taskbar' });
  });

  // Profile
  document.getElementById('profileNameInput').addEventListener('input', async (e) => {
    state.accountName = e.target.value || 'User'; await saveState(); renderProfile();
  });
  document.getElementById('profileAvatarUpload').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      state.avatar = reader.result; await saveState(); renderProfile();
    };
    reader.readAsDataURL(file);
  });
  document.getElementById('googleConnectBtn').addEventListener('click', connectGoogle);
  document.getElementById('googleDisconnectBtn').addEventListener('click', disconnectGoogle);

  // Global Escape closes overlays
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    closeSettings(); closeFolder(); closeAppEditor();
    document.getElementById('weatherOverlay').classList.add('hidden');
    document.getElementById('langMenu').classList.add('hidden');
    document.getElementById('taskbarPickOverlay').classList.add('hidden');
  });

  // Re-apply theme every few minutes in case "auto" crosses sunrise/sunset
  setInterval(applyThemeMode, 5 * 60 * 1000);
}
